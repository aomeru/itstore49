<?php

/**
 *  Config file that a user/developer can insert quickemailverficationservice api key
 */
return [
    'apiKey' => '3c068cecf67fa134c2c4ea16d5ba1666caf890b3bf58fb29941815adb40b'
];
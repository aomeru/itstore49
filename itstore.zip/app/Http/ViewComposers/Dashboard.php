<?php

namespace App\Http\ViewComposers;

use Illuminate\View\View;
use Auth;
use Session;
use App\Models\Support;
use App\Models\SupportMessages;
use App\Models\PrivateMail;
use App\Models\GuestMail;

class Dashboard
{

	public function compose(View $view)
	{
        
	}

}

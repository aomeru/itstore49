<div id="top" class="fixed">
	<nav class="navbar navbar-static-top">
		<div class="container-fluid m-0">
			<a class="navbar-brand float-left" href="#0">
                <h4 class="font-600">
                    <img src="{{asset('images/brand-name-w.png')}}" class="img-responsive mr10" width="120px" alt="logo" style="margin-top: -10px">
                </h4>
			</a>
			<div class="menu float-right">
				<span class="toggle-left" id="menu-toggle">
					<i class="fa fa-bars c-fff"></i>
				</span>
			</div>

		</div>
	</nav>
</div>
